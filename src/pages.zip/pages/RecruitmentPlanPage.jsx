// src/pages/RecruitmentPlanPage.jsx
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import Layout from "../components/Layout";
import Pagination from "../components/Pagination";
import ActionButtons from "../components/ActionButtons.jsx";
import AddPlanModal from "../components/AddPlanModal";
import DatePicker from "../components/DatePicker";
import Modal from "../components/Modal"; // ✅ Modal mới
import "../styles/plan.css";

// Hàm helper định dạng ngày
const formatDate = (dateString) => {
  if (!dateString) return "—";
  return new Date(dateString).toLocaleDateString("vi-VN");
};

// Map mã trạng thái -> label tiếng Việt
const getStatusLabel = (status) => {
  switch (status) {
    case "PENDING":
      return "Đã gửi đi";
    case "IN_PROGRESS":
      return "Đang xử lý";
    case "COMPLETED":
      return "Hoàn thành";
    case "CANCELED":
      return "Đã hủy";
    case "REJECTED":
      return "Bị từ chối";
    default:
      return status || "Không rõ";
  }
};

const RecruitmentPlanPage = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [plans, setPlans] = useState([]);
  const [filteredPlans, setFilteredPlans] = useState([]);
  const [searchName, setSearchName] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [isAnimating, setIsAnimating] = useState(false);

  const [openAddModal, setOpenAddModal] = useState(false);
  const [techSummary, setTechSummary] = useState([]);
  const [requestTitle, setRequestTitle] = useState("");
  const [modalMode, setModalMode] = useState("select"); // 'locked' | 'select'
  const [requestOptions, setRequestOptions] = useState([]);

  // ❌ Bỏ DRAFT, mặc định tạo kế hoạch là PENDING (đã gửi đi)
  const [form, setForm] = useState({
    requestId: undefined,
    planName: "",
    status: "PENDING",
    recruitmentDeadline: "",
    deliveryDeadline: "",
    note: "",
  });

  // 💎 STATE MODAL XEM CHI TIẾT / DUYỆT / TỪ CHỐI
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [modalStep, setModalStep] = useState(0); // 0: đóng, 1: xem, 2: đã duyệt, 3: từ chối
  const [rejectReason, setRejectReason] = useState("");

  const location = useLocation();
  const token = localStorage.getItem("token");
  const axiosAuth = axios.create({
    baseURL: "http://localhost:8080",
    headers: { Authorization: `Bearer ${token}` },
  });

  const loadPlans = async () => {
    try {
      setLoading(true);
      const res = await axiosAuth.get("/api/recruitment-plans");
      setPlans(res.data);
      setFilteredPlans(res.data);
      setError(null);
    } catch {
      setError("❌ Không thể tải danh sách kế hoạch tuyển dụng");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!token) {
      setError("⚠️ Bạn chưa đăng nhập hoặc token đã hết hạn");
      setLoading(false);
      return;
    }
    loadPlans();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mở AddPlan từ URL ?requestId=...
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const requestId = params.get("requestId");
    if (!requestId) return;

    (async () => {
      try {
        const res = await axiosAuth.get(`/api/hr-request/${requestId}/plan-defaults`);
        const d = res.data;
        setForm({
          requestId: d.requestId,
          planName: "",
          // ❌ Không dùng DRAFT nữa
          status: d.status || "PENDING",
          recruitmentDeadline: d.recruitmentDeadline || "",
          deliveryDeadline: d.deliveryDeadline || "",
          note: d.note || "",
        });
        setRequestTitle(d.suggestedPlanName || d.requestTitle || "");
        setTechSummary(d.techQuantities || []);
        setModalMode("locked");
        setOpenAddModal(true);
      } catch {
        setModalMode("locked");
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search]);

  // Lọc bảng
  useEffect(() => {
    let filtered = [...plans];
    if (searchName.trim()) {
      filtered = filtered.filter((p) =>
        (p.planName || "").toLowerCase().includes(searchName.toLowerCase())
      );
    }
    if (statusFilter) {
      filtered = filtered.filter((p) => p.status === statusFilter);
    }
    if (selectedDate) {
      const m = selectedDate.getMonth();
      const y = selectedDate.getFullYear();
      filtered = filtered.filter((p) => {
        const created = new Date(p.createdAt);
        return created.getMonth() === m && created.getFullYear() === y;
      });
    }
    setFilteredPlans(filtered);
    setCurrentPage(1);
  }, [searchName, statusFilter, selectedDate, plans]);

  const totalPages = Math.ceil(filteredPlans.length / itemsPerPage) || 1;
  const indexOfLast = currentPage * itemsPerPage;
  const indexOfFirst = indexOfLast - itemsPerPage;
  const currentPlans = filteredPlans.slice(indexOfFirst, indexOfLast);

  const handleChangeItemsPerPage = (e) => {
    setItemsPerPage(Number(e.target.value));
    setCurrentPage(1);
  };

  const handlePageChange = (p) => {
    if (p < 1 || p > totalPages) return;
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentPage(p);
      setIsAnimating(false);
    }, 180);
  };

  // Mở modal tạo kế hoạch mới (chọn nhu cầu NEW)
  const openEmptyAddModal = async () => {
    setForm({
      requestId: undefined,
      planName: "",
      // ❌ Không dùng DRAFT nữa
      status: "PENDING",
      recruitmentDeadline: "",
      deliveryDeadline: "",
      note: "",
    });
    setTechSummary([]);
    setRequestTitle("");
    setModalMode("select");

    try {
      const res = await axiosAuth.get("/api/hr-request");
      const opts = (res.data || [])
        .filter((r) => String(r.status || "").toUpperCase() === "NEW")
        .map((r) => ({ id: r.requestId, title: r.requestTitle }))
        .sort((a, b) => a.title.localeCompare(b.title));
      setRequestOptions(opts);
    } catch {
      setRequestOptions([]);
    }
    setOpenAddModal(true);
  };

  const handlePickRequest = async (id) => {
    if (!id) {
      setForm((f) => ({
        ...f,
        requestId: undefined,
        recruitmentDeadline: "",
        deliveryDeadline: "",
      }));
      setTechSummary([]);
      setRequestTitle("");
      return;
    }
    try {
      const res = await axiosAuth.get(`/api/hr-request/${id}/plan-defaults`);
      const d = res.data;
      setForm({
        requestId: d.requestId,
        planName: "",
        // ❌ Không dùng DRAFT nữa
        status: d.status || "PENDING",
        recruitmentDeadline: d.recruitmentDeadline || "",
        deliveryDeadline: d.deliveryDeadline || "",
        note: d.note || "",
      });
      setRequestTitle(d.suggestedPlanName || d.requestTitle || "");
      setTechSummary(d.techQuantities || []);
    } catch {
      setForm((f) => ({
        ...f,
        requestId: undefined,
        recruitmentDeadline: "",
        deliveryDeadline: "",
      }));
      setTechSummary([]);
      setRequestTitle("");
    }
  };

  const submitPlan = async () => {
    try {
      if (!form.requestId) {
        alert("⚠️ Vui lòng chọn nhu cầu (NEW) trước khi tạo kế hoạch.");
        return;
      }
      if (!form.planName || !form.recruitmentDeadline || !form.deliveryDeadline) {
        alert("⚠️ Vui lòng nhập tên kế hoạch.");
        return;
      }
      // 📌 Khi gửi lên backend, status hiện tại đang là "PENDING"
      await axiosAuth.post("/api/recruitment-plans", form);
      setOpenAddModal(false);
      await loadPlans();
      alert("✅ Tạo kế hoạch thành công!");
    } catch (e) {
      const msg = e?.response?.data?.message || e?.message || "Lỗi không xác định";
      alert(`⚠️ Không thể tạo kế hoạch: ${msg}`);
    }
  };

  // ==== MODAL HANDLERS ====
  const handleViewDetails = (plan) => {
    setSelectedPlan(plan);
    setModalStep(1); // mở modal xem chi tiết
  };

  const handleApprove = () => {
    // Tạm thời chỉ hiển thị modal “Đã xác nhận”
    setModalStep(2);
  };

  const handleStartReject = () => {
    setModalStep(3);
    setRejectReason("");
  };

  const handleCloseModal = () => {
    setModalStep(0);
    setSelectedPlan(null);
    setRejectReason("");
  };

  const handleSubmitRejection = async () => {
    if (!selectedPlan) return;
    const planId = selectedPlan.recruitmentPlanId;

    if (!planId || !rejectReason.trim()) {
      alert("Lý do từ chối không được để trống.");
      return;
    }

    try {
      const res = await axiosAuth.post(
        `/api/recruitment-plans/${planId}/reject`,
        { rejectionReason: rejectReason }
      );

      alert(res.data?.message || "Đã từ chối kế hoạch.");

      const updatedPlanData = { status: "CANCELED", note: rejectReason };

      setPlans((prev) =>
        prev.map((p) =>
          p.recruitmentPlanId === planId ? { ...p, ...updatedPlanData } : p
        )
      );
      setFilteredPlans((prev) =>
        prev.map((p) =>
          p.recruitmentPlanId === planId ? { ...p, ...updatedPlanData } : p
        )
      );
      setSelectedPlan((prev) => (prev ? { ...prev, ...updatedPlanData } : prev));

      handleCloseModal();
    } catch (error) {
      console.error("Lỗi khi từ chối:", error);
      alert(error.response?.data?.error || "Lỗi không xác định khi từ chối.");
    }
  };

  // Render chi tiết kế hoạch trong modal
  const renderPlanDetails = (plan, showStatus = false) => {
    if (!plan) return null;

    const request = plan.request;
    if (!request) {
      console.error("Plan không có 'request' object:", plan);
      return (
        <p className="error-text">
          Lỗi: Kế hoạch này thiếu thông tin nhu cầu (request).
        </p>
      );
    }

    return (
      <div className="detail-list">
        <div className="detail-item">
          <span className="detail-label">Tên nhu cầu:</span>
          <span className="detail-value">{request.requestTitle}</span>
        </div>
        <div className="detail-item">
          <span className="detail-label">Tên kế hoạch:</span>
          <span className="detail-value">{plan.planName}</span>
        </div>

        <table className="tech-table">
          <thead>
            <tr>
              <th>Công nghệ</th>
              <th className="text-center">Đầu ra (SL)</th>
              <th className="text-center">Đầu vào (SL)</th>
            </tr>
          </thead>
          <tbody>
            {request.quantityCandidates && request.quantityCandidates.length > 0 ? (
              request.quantityCandidates.map((qc) => (
                <tr key={qc.technology.id}>
                  <td>{qc.technology.name}</td>
                  <td className="text-center">{qc.soLuong}</td>
                  <td className="text-center">{qc.soLuong * 2}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="3" className="text-center">
                  Không có thông tin công nghệ.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div className="detail-item">
          <span className="detail-label">Thời hạn tuyển dụng:</span>
          <span className="detail-value">
            {formatDate(plan.recruitmentDeadline)}
          </span>
        </div>
        <div className="detail-item">
          <span className="detail-label">Thời hạn bàn giao:</span>
          <span className="detail-value">
            {formatDate(plan.deliveryDeadline)}
          </span>
        </div>

        {showStatus && (
          <div className="detail-item">
            <span className="detail-label">Trạng thái:</span>
            <span className="detail-value status-confirmed">
              {getStatusLabel(plan.status)}
            </span>
          </div>
        )}
      </div>
    );
  };

  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="breadcrumb-container fade-slide">
        <div className="breadcrumb-left">
          <span className="breadcrumb-icon">💼</span>
          <span className="breadcrumb-item">Tuyển dụng</span>
          <span className="breadcrumb-separator">&gt;</span>
          <span className="breadcrumb-current">Kế hoạch tuyển dụng</span>
        </div>
        <div className="breadcrumb-right">
          <div className="mini-pagination">
            <label className="mini-pagination-label">Hiển thị:</label>
            <select
              value={itemsPerPage}
              onChange={handleChangeItemsPerPage}
              className="mini-pagination-select smooth-dropdown"
            >
              <option value={10}>10</option>
              <option value={15}>15</option>
              <option value={20}>20</option>
            </select>
          </div>
        </div>
      </div>

      {/* Nội dung chính */}
      <div className="recruitment-page fade-slide">
        <div className="title-row">
          <h2 className="page-title-small">Kế hoạch tuyển dụng</h2>

          <div className="filter-bar">
            {/* Search + datalist recentNames */}
            <div className="filter-item search-wrapper">
              <div className="search-input-container">
                <input
                  type="text"
                  className="filter-input search-input"
                  placeholder="Tìm theo tên..."
                  value={searchName}
                  onChange={(e) => setSearchName(e.target.value)}
                  list="recent-names"
                />
                <span className="filter-icon">🔍</span>
                <datalist id="recent-names">
                  {(JSON.parse(localStorage.getItem("recentNames") || "[]")).map(
                    (name, i) => (
                      <option key={i} value={name} />
                    )
                  )}
                </datalist>
              </div>
            </div>

            {/* Trạng thái */}
            <div className="filter-item">
              <select
                className="filter-select smooth-dropdown"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">Trạng thái</option>
                {/* ❌ Không còn DRAFT */}
                <option value="PENDING">Đã gửi đi</option>
                <option value="IN_PROGRESS">Đang xử lý</option>
                <option value="COMPLETED">Hoàn thành</option>
                <option value="CANCELED">Đã hủy</option>
                <option value="REJECTED">Bị từ chối</option>
              </select>
            </div>

            {/* Lọc theo tháng/năm tạo */}
            <div className="filter-item">
              <DatePicker
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
              />
            </div>

            {/* Nút thêm kế hoạch */}
            <div className="filter-item add-btn-wrapper">
              <button className="add-plan-btn modern-add" onClick={openEmptyAddModal}>
                ＋ Thêm kế hoạch tuyển dụng
              </button>
            </div>
          </div>
        </div>

        {/* Nút xoá tất cả filter */}
        <div className="filter-item">
          <button
            className="clear-all-btn smooth-dropdown"
            onClick={() => {
              setSearchName("");
              setStatusFilter("");
              setSelectedDate(null);
            }}
          >
            Xóa tất cả bộ lọc
          </button>
        </div>

        {/* Bảng */}
        <div className={`table-container ${isAnimating ? "fade-out" : "fade-in"}`}>
          {loading ? (
            <p className="loading-text">Đang tải dữ liệu...</p>
          ) : error ? (
            <p className="error-text">{error}</p>
          ) : (
            <table className="styled-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Tên kế hoạch</th>
                  <th>Ngày tạo</th>
                  <th>Trạng thái</th>
                  <th>Người gửi</th>
                  <th>Hành động</th>
                </tr>
              </thead>
              <tbody>
                {currentPlans.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center">
                      Không có dữ liệu
                    </td>
                  </tr>
                ) : (
                  currentPlans.map((plan, index) => {
                    // 🔒 Cho phép sửa hay không: chỉ cho sửa khi PENDING (Đã gửi đi)
                    const canEdit = plan.status === "PENDING";

                    return (
                      <tr key={plan.recruitmentPlanId || index}>
                        <td>{indexOfFirst + index + 1}</td>
                        <td>{plan.planName}</td>
                        <td>
                          {plan.createdAt ? formatDate(plan.createdAt) : "—"}
                        </td>
                        <td>
                          <span className="status-badge">
                            {getStatusLabel(plan.status)}
                          </span>
                        </td>
                        <td>
                          {plan.request?.createdBy?.fullName ||
                            plan.request?.createdBy?.username ||
                            "Không rõ"}
                        </td>
                        <td className="actions-cell text-center">
                          <ActionButtons
                            onView={() => handleViewDetails(plan)}
                            onEdit={() => {
                              if (!canEdit) {
                                alert(
                                  'Chỉ được chỉnh sửa khi kế hoạch đang ở trạng thái "Đã gửi đi".'
                                );
                                return;
                              }
                              console.log(
                                "Chỉnh sửa kế hoạch",
                                plan.recruitmentPlanId
                              );
                              // TODO: sau này bạn có thể mở modal sửa / chuyển sang trang edit
                            }}
                          />
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          )}
        </div>

        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </div>

      {/* Modal tạo kế hoạch (giữ logic gốc) */}
      <AddPlanModal
        open={openAddModal}
        onClose={() => setOpenAddModal(false)}
        form={form}
        onChange={setForm}
        onSubmit={submitPlan}
        techSummary={techSummary}
        requestTitle={requestTitle}
        mode={modalMode}
        requestOptions={requestOptions}
        onPickRequest={handlePickRequest}
      />

      {/* 1. Modal Xem chi tiết */}
      {modalStep === 1 && selectedPlan && (
        <Modal
          title="Chi tiết Kế hoạch tuyển dụng"
          onClose={handleCloseModal}
          width={600}
        >
          {renderPlanDetails(selectedPlan, false)}

          {selectedPlan.status === "PENDING" ? (
            <div className="modal-footer">
              <button
                className="modal-btn btn-reject"
                onClick={handleStartReject}
              >
                Từ chối
              </button>
              <button
                className="modal-btn btn-approve"
                onClick={handleApprove}
              >
                Phê duyệt
              </button>
            </div>
          ) : selectedPlan.status === "CANCELED" ||
            selectedPlan.status === "REJECTED" ? (
            <div className="modal-footer-canceled">
              <p className="rejection-title">
                LÝ DO KẾ HOẠCH BỊ{" "}
                {selectedPlan.status === "CANCELED" ? "HỦY" : "TỪ CHỐI"}:
              </p>
              <p className="rejection-reason-text">
                {selectedPlan.note || "Không có lý do cụ thể được ghi lại."}
              </p>
              <button
                className="modal-btn btn-secondary"
                onClick={handleCloseModal}
              >
                Đóng
              </button>
            </div>
          ) : (
            <div className="modal-footer justify-content-center">
              <p
                style={{
                  margin: 0,
                  color: "#6b7280",
                  fontWeight: 600,
                }}
              >
                Kế hoạch đang ở trạng thái "{getStatusLabel(selectedPlan.status)}".
                Chỉ có thể xem.
              </p>
              <button
                className="modal-btn btn-secondary"
                onClick={handleCloseModal}
              >
                Đóng
              </button>
            </div>
          )}
        </Modal>
      )}

      {/* 2. Modal Đã duyệt */}
      {modalStep === 2 && selectedPlan && (
        <Modal
          title="Kế hoạch Đã xác nhận"
          onClose={handleCloseModal}
          width={600}
        >
          {renderPlanDetails(selectedPlan, true)}
          <div className="modal-footer">
            <button
              className="modal-btn btn-secondary"
              onClick={() => console.log("Xem kết quả đào tạo")}
            >
              Xem kết quả đào tạo
            </button>
            <button
              className="modal-btn btn-approve"
              onClick={() => console.log("Xem kết quả tuyển dụng")}
            >
              Xem kết quả tuyển dụng
            </button>
          </div>
        </Modal>
      )}

      {/* 3. Modal Từ chối */}
      {modalStep === 3 && selectedPlan && (
        <Modal
          title="Lý do Từ chối Kế hoạch"
          onClose={handleCloseModal}
          width={500}
        >
          <div className="reject-form">
            <label htmlFor="rejectReason">
              Vui lòng nhập lý do từ chối kế hoạch: "{selectedPlan.planName}"
            </label>
            <textarea
              id="rejectReason"
              className="reject-textarea"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Nhập lý do..."
            />
          </div>
          <div className="modal-footer">
            <button
              className="modal-btn btn-secondary"
              onClick={handleCloseModal}
            >
              Hủy
            </button>
            <button
              className="modal-btn btn-reject"
              onClick={handleSubmitRejection}
              disabled={!rejectReason.trim()}
            >
              Xác nhận từ chối
            </button>
          </div>
        </Modal>
      )}
    </Layout>
  );
};

export default RecruitmentPlanPage;
